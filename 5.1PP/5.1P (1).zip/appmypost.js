const app = Vue.createApp({ })

app.component('app-mypost', {
  data: function() {
    return {
      statPosts: [],
      strStatus: ''
    }
  },
  template: `
    <div>
        <b>Status:</b>
      <input type="text" v-model="strStatus">
      <button v-on:click="addStatus">Post</button>
      <div v-for="(status, index) in statPosts">
        <p>{{ status }}</p> 
        <button v-on:click="removeStatus(index)">Delete</button>
      </div>
    </div>
  `,
  methods: {
    addStatus: function() {
        if (this.strStatus !== '') {
          this.statPosts.push(this.strStatus);
          this.strStatus = '';
        }
    },
    removeStatus: function(index) {
      this.statPosts.splice(index, 1);
    }
  }
});

app.mount('#app');