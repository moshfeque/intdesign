const ReadMysql ={
  template: `
  <v-row>

    <v-col cols="12" md="12 " >

    <v-card
       class="mx-auto"
       max-width="90%"
       >

       <v-card-title>
       <h2>Units Information</h2>
       </v-card-title>

       <v-card-text>
       <ul class="list-group">
         <li class="list-group-item" v-for="person in getItems" :key="person.name" >
           Unit Code: {{person.code}} | Description: {{person.name}} | Credit Points: {{person.cp}} | Type: {{person.type}}
         </li>
       </ul>

        </v-card-text>
        </v-card>
        </v-col>

       <v-col cols="12" md="12">
       <paginate
     :page-count=getPageCount
     :page-range="3"
     :margin-pages="1"
     :click-handler="clickCallback"
     :prev-text=" 'Prev' "
     :next-text="'Next'"
     :container-class="'pagination'"
     :page-class="'page-item'"
	 :active-class="'currentPage'">
     </paginate>
     </v-col>
     </v-row>
   `,
  data: function() {
    return {
      perPage:3,
      currentPage:1,
      persons: []
    }
  },
  components: {
			paginate: VuejsPaginateNext,
	},
  computed:{
    getItems: function() {
        let current = this.currentPage * this.perPage;
        let start = current - this.perPage;
        return this.persons.slice(start, current);
     },
     getPageCount: function() {
      return Math.ceil(this.persons.length / this.perPage);
     }
  },
  methods:{
      clickCallback: function(pageNum){
        this.currentPage = Number(pageNum);
      }
    },
  created() {
    var self = this
    var readSQLApiURL = 'resources/apis.php/' 


	        fetch(readSQLApiURL )
			.then( response =>{
			  return response.json( );
			})
			.then( data =>{
			  self.persons=data;
			})
			.catch(error => {
			  self.errorMessage = error;
			});
	  
  }
} 