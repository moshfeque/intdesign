import Vue from 'vue'
import VueRouter from 'vue-router'
import router from './main.js'
import SubjectsPage from './components/SubjectsPage.vue';
import HomePage from './components/HomePage.vue';
import PostStatus from './components/PostStatus.vue';

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: HomePage
  },
  {
    path: '/poststatus',
    name: 'PostStatus',
    component: PostStatus
  },
  {
    path: '/about',
    name: 'StudentMarks',
    component: SubjectsPage
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router