<template>
 
  <div id="app">
    <router-link to="/">Home</router-link> |
    <router-link to="/poststatus">Post Management</router-link> |
    <router-link to="/subjects">Units Information</router-link>
    <router-view></router-view>
  </div>
</template>

<script>

export default {
  name: 'App',
  components: {},
}
</script>