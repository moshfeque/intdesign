import { createApp } from 'vue';
import App from './App.vue';
import HomePage from './components/HomePage.vue';
import PostStatus from './components/PostStatus.vue';
import SubjectsPage from './components/SubjectsPage.vue';
import { createRouter } from 'vue-router';
import {createWebHistory} from 'vue-router';

const routes = [
    {
        path: '/',
        component: HomePage,
    },
    {
        path: '/poststatus',
        component: PostStatus,
    },  
    {
        path: '/subjects',
        component: SubjectsPage,
    },  
];

const router = createRouter({
    history: createWebHistory(process.env.BASE_URL),
    routes: routes,
});

const app = createApp(App);
app.use(router);
app.mount('#app');
