<template>
  <h1>Units Information</h1>
  <div class="container">
    <table class="table">
      <thead>
        <tr>
          <th scope="col" id="code">Code</th>
          <th scope="col" id="desc">Description</th>
          <th scope="col" id="cp">Credit Points</th>
          <th scope="col" id="type">Type</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(units, index) in displayedStudents" :key="index">
          <td :headers="['code']">{{ units.code }}</td>
          <td :headers="['desc']">{{ units.desc }}</td>
          <td :headers="['cp']">{{ units.cp }}</td>
          <td :headers="['type']">{{ units.type }}</td>
        </tr>
      </tbody>
    </table>
    <nav aria-label="Page navigation">
      <ul class="pagination">
        <li class="page-item" :class="{ disabled: currentPage === 0 }">
          <a class="page-link" href="#" @click.prevent="prevPage()">Previous</a>
        </li>
        <li class="page-item" v-for="(page, index) in pages" :key="index" :class="{ active: currentPage === index }">
          <a class="page-link" href="#" @click.prevent="changePage(index)">{{ index + 1 }}</a>
        </li>
        <li class="page-item" :class="{ disabled: currentPage === pageCount - 1 }">
          <a class="page-link" href="#" @click.prevent="nextPage()">Next</a>
        </li>
      </ul>
    </nav>
  </div>
</template>

<script>
export default {
  name: 'SubjectsPage',
  data() {
    return {
      subjects: [
        { "code": "ICT10001", "desc": "Problem Solving with ICT", "cp": 12.5, "type": "Core" },
        { "code": "COS10005", "desc": "Web Development", "cp": 12.5, "type": "Core" },
        { "code": "INF10003", "desc": "Introduction to Business Information Systems", "cp": 12.5, "type": "Core" },
        { "code": "INF10002", "desc": "Database Analysis and Design", "cp": 12.5, "type": "Core" },
        { "code": "COS10009", "desc": "Introduction to Programming", "cp": 12.5, "type": "Core" },
        { "code": "INF30029", "desc": "Information Technology Project Management", "cp": 12.5, "type": "Core" },
        { "code": "ICT30005", "desc": "Professional Issues in Information Technology", "cp": 12.5, "type": "Core" },
        { "code": "ICT30001", "desc": "Information Technology Project", "cp": 12.5, "type": "Core" },
        { "code": "COS20001", "desc": "User-Centred Design", "cp": 12.5, "type": "Software Development" },
        { "code": "TNE10005", "desc": "Network Administration", "cp": 12.5, "type": "Software Development" },
        { "code": "COS20016", "desc": "Operating System Configuration", "cp": 12.5, "type": "Software Development" },
        { "code": "SWE20001", "desc": "Development Project 1 - Tools and Practices", "cp": 12.5, "type": "Software Development" },
        { "code": "COS20007", "desc": "Object Oriented Programming", "cp": 12.5, "type": "Software Development" },
        { "code": "COS30015", "desc": "IT Security", "cp": 12.5, "type": "Software Development" },
        { "code": "COS30043", "desc": "Interface Design and Development", "cp": 12.5, "type": "Software Development" },
        { "code": "COS30017", "desc": "Software Development for Mobile Devices", "cp": 12.5, "type": "Software Development" },
        { "code": "INF20012", "desc": "Enterprise Systems", "cp": 12.5, "type": "Systems Analysis" },
        { "code": "ACC10007", "desc": "Financial Information for Decision Making", "cp": 12.5, "type": "Systems Analysis" },
        { "code": "INF20003", "desc": "Requirements Analysis and Modelling", "cp": 12.5, "type": "Systems Analysis" },
        { "code": "ACC20014", "desc": "Management Decision Making", "cp": 12.5, "type": "Systems Analysis" },
        { "code": "INF30005", "desc": "Business Process Management", "cp": 12.5, "type": "Systems Analysis" },
        { "code": "INF30003", "desc": "Business Information Systems Analysis", "cp": 12.5, "type": "Systems Analysis" },
        { "code": "INF30020", "desc": "Information Systems Risk and Security", "cp": 12.5, "type": "Systems Analysis" },
        { "code": "INF30001", "desc": "Systems Acquisition & Implementation Management", "cp": 12.5, "type": "Systems Analysis" }
      ],
      currentPage: 0,
      pageSize: 3,
    };
  },
  computed: {
    pageCount() {
      return Math.ceil(this.subjects.length / this.pageSize);
    },
    pages() {
      let pages = [];
      for (let i = 0; i < this.pageCount; i++) {
        pages.push(i);
      }
      return pages;
    },
    displayedStudents() {
      let start = this.currentPage * this.pageSize;
      let end = start + this.pageSize;
      return this.subjects.slice(start, end);
    },
  },
  methods: {
    nextPage() {
      if (this.currentPage < this.pageCount - 1) {
        this.currentPage++;
      }
    },
    prevPage() {
      if (this.currentPage > 0) {
        this.currentPage--;
      }
    },
    changePage(page) {
      this.currentPage = page;
    },
  },
};
</script>

