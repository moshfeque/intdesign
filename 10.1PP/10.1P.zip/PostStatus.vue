<template>
    <div class="container">
      <h1>My Status App</h1>
      <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="Enter your status here" v-model="newStatus">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button" @click="addStatus()">Post</button>
        </div>
      </div>
      <div class="status-list">
        <div v-for="(status, index) in statusList" :key="index" class="status-item">
          <p>{{ status }}</p>
          <button class="btn btn-danger" @click="deleteStatus(index)">Delete</button>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'PostStatus',
    data() {
      return {
        newStatus: '',
        statusList: []
      }
    },
    methods: {
      addStatus() {
        if (this.newStatus !== '') {
          this.statusList.push(this.newStatus);
          this.newStatus = '';
        }
      },
      deleteStatus(index) {
        this.statusList.splice(index, 1);
      }
    }
  }
  </script>
  
  <style>
  .status-list {
    margin-top: 20px;
  }
  
  .status-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #f5f5f5;
    padding: 10px;
    margin-bottom: 10px;
  }
  
  .status-item p {
    margin: 0;
  }
  </style>