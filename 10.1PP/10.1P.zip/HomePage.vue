<template>
  <div>
    <h1>Welcome to the Home Page!</h1>
    <form>
      <label for="first-name">First Name:</label>
      <input type="text" id="first-name" v-model="firstName" />
      <br />
      <label for="last-name">Last Name:</label>
      <input type="text" id="last-name" v-model="lastName" />
      <br />
      <label>Choose your favorite scenery:</label>
      <input type="radio" id="mountain" value="mountain" v-model="scenery" />
      <label for="mountain">Mountain</label>
      <input type="radio" id="ocean" value="ocean" v-model="scenery" />
      <label for="ocean">Ocean</label>
    </form>
    <p v-if="firstName && lastName">Welcome, {{ firstName }} {{ lastName }}!</p>
    <img v-if="scenery === 'mountain'" src="./mountain.jpg" alt="Mountain" />
    <img v-if="scenery === 'ocean'" src="./ocean.jpg" alt="Ocean" />
  </div>
</template>

<script>
export default {
  name: 'HomePage',
  data() {
    return {
      firstName: '',
      lastName: '',
      scenery: '',
    };
  },
};
</script>