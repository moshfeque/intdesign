import Vue from 'vue'
import VueRouter from 'vue-router'
import router from './main.js'
import NameTest from './components/NameTest.vue';
import PostStatus from './components/PostStatus.vue';
import StudentMarks from './components/StudentMarks.vue';

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'NameTest',
    component: NameTest
  },
  {
    path: '/poststatus',
    name: 'PostStatus',
    component: PostStatus
  },
  {
    path: '/about',
    name: 'StudentMarks',
    component: StudentMarks
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router