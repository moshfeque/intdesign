import { createApp } from 'vue';
import App from './App.vue';
import NameTest from './components/NameTest.vue';
import PostStatus from './components/PostStatus.vue';
import StudentMarks from './components/StudentMarks.vue';
import { createRouter } from 'vue-router';
import {createWebHistory} from 'vue-router';

const routes = [
    {
        path: '/',
        component: NameTest,
    },
    {
        path: '/poststatus',
        component: PostStatus,
    },  
    {
        path: '/studentmarks',
        component: StudentMarks,
    },  
];

const router = createRouter({
    history: createWebHistory(process.env.BASE_URL),
    routes: routes,
});

const app = createApp(App);
app.use(router);
app.mount('#app');
