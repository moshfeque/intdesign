<template>
    <div>
      <label>Please enter your name:</label>
      <input type="text" v-model="strName" />
      <p v-if="strName.toLowerCase() == 'moshfeque'">Awesome name!</p>
      <p v-else-if="strName">{{ strName }} is not my name!</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'NameTest',
    data() {
      return {
        strName: "",
      };
    },
  };
  </script>