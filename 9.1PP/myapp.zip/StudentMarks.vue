<template>
  <h1>Student Marks</h1>
  <div class="container">
    <table class="table">
      <thead>
        <tr>
          <th scope="col" id="name">Name</th>
          <th scope="col" id="mark">Mark</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(student, index) in displayedStudents" :key="index">
          <td :headers="['name']">{{ student.name }}</td>
          <td :headers="['mark']">{{ student.mark }}</td>
        </tr>
      </tbody>
    </table>
    <nav aria-label="Page navigation">
      <ul class="pagination">
        <li class="page-item" :class="{disabled: currentPage === 0}">
          <a class="page-link" href="#" @click.prevent="prevPage()">Previous</a>
        </li>
        <li class="page-item" v-for="(page, index) in pages" :key="index" :class="{active: currentPage === index}">
          <a class="page-link" href="#" @click.prevent="changePage(index)">{{ index + 1 }}</a>
        </li>
        <li class="page-item" :class="{disabled: currentPage === pageCount - 1}">
          <a class="page-link" href="#" @click.prevent="nextPage()">Next</a>
        </li>
      </ul>
    </nav>
  </div>
</template>

<script>
export default {
  name: 'StudentMarks',
  data() {
    return {
      studMarks: [
      { "name": "Amy", "mark": 90 },
	{ "name": "Bill", "mark": 80 },
	{ "name": "Casey", "mark": 78 },
	{ "name": "David", "mark": 84 },
	{ "name": "Emily", "mark": 92 },
	{ "name": "Frank", "mark": 87 },
	{ "name": "Grace", "mark": 93 },
	{ "name": "Henry", "mark": 79 },
	{ "name": "Isaac", "mark": 85 },
	{ "name": "Jack", "mark": 75 },
	{ "name": "Kate", "mark": 91 },
	{ "name": "Liam", "mark": 76 },
	{ "name": "Mia", "mark": 88 },
	{ "name": "Nick", "mark": 82 },
	{ "name": "Olivia", "mark": 96 },
	{ "name": "Pete", "mark": 70 },
	{ "name": "Quinn", "mark": 83 },
	{ "name": "Rachel", "mark": 89 },
	{ "name": "Steve", "mark": 81 },
	{ "name": "Tom", "mark": 77 },
	{ "name": "Uma", "mark": 86 },
	{ "name": "Vicky", "mark": 94 },
	{ "name": "Wendy", "mark": 72 },
	{ "name": "Xander", "mark": 73 },
	{ "name": "Yara", "mark": 95 },
	{ "name": "Zoe", "mark": 97 }
      ],
      currentPage: 0,
      pageSize: 3,
    };
  },
  computed: {
    pageCount() {
      return Math.ceil(this.studMarks.length / this.pageSize);
    },
    pages() {
      let pages = [];
      for (let i = 0; i < this.pageCount; i++) {
        pages.push(i);
      }
      return pages;
    },
    displayedStudents() {
      let start = this.currentPage * this.pageSize;
      let end = start + this.pageSize;
      return this.studMarks.slice(start, end);
    },
  },
  methods: {
    nextPage() {
      if (this.currentPage < this.pageCount - 1) {
        this.currentPage++;
      }
    },
    prevPage() {
      if (this.currentPage > 0) {
        this.currentPage--;
      }
    },
    changePage(page) {
      this.currentPage = page;
    },
  },
};
</script>

