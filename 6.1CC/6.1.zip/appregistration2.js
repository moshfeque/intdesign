    const { createApp } = Vue

    const app = createApp({
        data() {
            return {
                fName: '', 
                lName: '',
                uName: '',
                password: '',
                confirmPassword: '',
                email: '',
                streetAddress: '',
                suburb: '',
                postcode: '',
                mobileNumber: '',
                errors: [],
                showTerms: false
            }
        },
        methods: {
            checkForm: function(e){
                var result = true
                this.errors = []
                if (!this.fName.trim()) {
                    result = false
                    this.errors.push("Please enter first name.")		
                }
                if (!/^[a-zA-Z]*$/g.test(this.fName)) {
                    result = false
                    this.errors.push("First name should contain only letters.")		
                }
                if (!this.lName.trim()) {
                    result = false
                    this.errors.push("Please enter last name.")		
                }
                if (!/^[a-zA-Z]*$/g.test(this.lName)) {
                    result = false
                    this.errors.push("Last name should contain only letters.")		
                }
                if (!this.uName.trim()) {
                    result = false
                    this.errors.push("Please enter user name.")		
                }
                if (this.uName.trim().length < 3) {
                    result = false
                    this.errors.push("User name should be at least 3 characters long.")		
                }
                if (!this.password) {
                    result = false
                    this.errors.push("Please enter password.")		
                }
                if (!/^(?=.*[$%*^&])[A-Za-z\d@$!%*#?&]{8,}$/g.test(this.password)) {
                    result = false
                    this.errors.push("Password must contain at least 1 special character, minimum 8 characters.")		
                }
                if (this.password !== this.confirmPassword) {
                    result = false
                    this.errors.push("Confirm password should match the password.")		
                }
                if (!this.email.trim()) {
                    result = false
                    this.errors.push("Please enter email address.")		
                }
                if (!/\S+@\S+\.\S+/.test(this.email)) {
                    result = false
                    this.errors.push("Please enter valid email address.")		
                }
                if (this.streetAddress.trim() && this.streetAddress.length > 40) {
                    result = false
                    this.errors.push("Street address should be maximum of 40 characters.")		
                }
                if (this.suburb.trim() && this.suburb.length > 20) {
                    result = false
                    this.errors.push("Suburb should be maximum of 20 characters.")		
                }
                if (!this.postcode.trim()) {
                    result = false
                    this.errors.push("Please enter postcode.")		
                }
                if (!/^\d{4}$/g.test(this.postcode)) {
                    result = false
                    this.errors.push("Postcode must contain exactly 4 numeric digits.")		
                }
                if (!this.mobileNumber.trim()) {
                    result = false
                    this.errors.push("Please enter mobile number.")
                }
                if (!/^\d{10}$/.test(this.mobileNumber)) {
                    result = false
                    this.errors.push("Mobile number should be 10 digits long.")
                }
                if (!/^04/.test(this.mobileNumber)) {
                    result = false
                    this.errors.push("Mobile number should start with 04.")
                }
                if (!result)
                    e.preventDefault()		
            }
        }
    })

    app.mount('#app')