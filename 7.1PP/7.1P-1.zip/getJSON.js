const { createApp } = Vue
	const app = createApp()
 
	app.component('app-readjson', {   
		data: function(){
			return  {msg: [ ]} 
		},  
		template: `	
		<ul>
			<p v-for="m in msg">
             {{ m.id }} -- {{m.title}}     
			</p>
		</ul>
		`,
		mounted() { 
			var self = this;
			$.getJSON('https://jsonplaceholder.typicode.com/posts', function(data) {
				self.msg = data; 
    			})
			.fail(function() { alert('getJSON request failed! '); })
  		}
	})
	
	app.mount('#app')