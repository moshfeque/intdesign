// Initialize the array of objects with the following unit information
var subjects = [
    { code: 'ICT10001', desc: 'Problem Solving with ICT', credit: 12.5, type: 'Core' },
    { code: 'COS10005', desc: 'Web Development', credit: 12.5, type: 'Core' },
    { code: 'INF10003', desc: 'Introduction to Business Information Systems', credit: 12.5, type: 'Core' },
    { code: 'INF10002', desc: 'Database Analysis and Design', credit: 12.5, type: 'Core' },
    { code: 'COS10009', desc: 'Introduction to Programming', credit: 12.5, type: 'Core' },
    { code: 'INF30029', desc: 'Information Technology Project Management', credit: 12.5, type: 'Core' },
    { code: 'ICT30005', desc: 'Professional Issues in Information Technology', credit: 12.5, type: 'Core' },
    { code: 'ICT30001', desc: 'Information Technology Project', credit: 12.5, type: 'Core' }
    ];
    
    // Create a component for the units to pass in the router
    const Subject = {
    data:function() {
    return {
    subjects
    }
    },
    // Define the template for the route results
    template: `<div>
            <hr>
            <h2>Unit Code: {{ $route.params.id }}</h2>
            <ul v-for="unit in filteredUnits">
                <li><strong>Code: </strong>{{unit.code}}</li>
                <li><strong>Description: </strong>{{unit.desc}}</li>
                <li><strong>Credit: </strong>{{unit.credit}}</li>
                <li><strong>Type: </strong>{{unit.type}}</li>
            </ul>
            </div> `,
    computed: {
    // Filter function (returns the selected unit object)
    filteredUnits: function() {
    return this.subjects.filter(s => s.code.toLowerCase().match((this.$route.params.id.toLowerCase())));
    }
}
    }
    
    // Create the VueRouter
    const router = VueRouter.createRouter({
    history: VueRouter.createWebHashHistory(),
    routes: [{
    path: '/subject/:id',
    component: Subject
    }]
    })
    
    // Create a new app instance
    const app = Vue.createApp({})
    
    // Create a component for the lookup table
    app.component('app-lookup2', {
    data: function() {
    return {
    subjects
    }
    },
    // Define the template for the app
    template:
     `<div>
			<table >
				<tr>
					<th>Code</th>
					<th>Description</th>
					<th>More Info</th>
				</tr>   
				<tr v-for="s in subjects">
					<td>{{ s.code }}</td>
					<td>{{ s.desc }}</td>
					<td><router-link :to="{ path:'/subject/'+s.code }">Read More</router-link></td>
				</tr>
			</table>
			
			<router-view ></router-view>		
		</div> `
})
    
    // Use router, mount to app
    app.use(router)
    app.mount('#app')